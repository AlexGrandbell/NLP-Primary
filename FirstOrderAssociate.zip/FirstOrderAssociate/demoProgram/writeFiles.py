from paths import *
import json

#写入新文档序号
def writeFileIndexs(newFileIndexs):
    with open(fileIndexsPath, 'w', encoding='utf-8') as f:
        json.dump(newFileIndexs, f, ensure_ascii=False)

#写入新的倒排索引
def writeInvertedIndex(invertedIndex):
    #将set类型的值转换为list类型
    invertedIndex = {key: list(value) for key, value in invertedIndex.items()}
    with open(invertedIndexPath, 'w', encoding='utf-8') as f:
        json.dump(invertedIndex, f, ensure_ascii=False)

#写入新的词语次数
def writeWordCount(wordCount):
    with open(wordCountPath, 'w', encoding='utf-8') as f:
        json.dump(wordCount, f, ensure_ascii=False)

#写入新的词语相邻词语次数
def writeNextWordCount(nextWordCount):
    with open(nextWordCountPath, 'w', encoding='utf-8') as f:
        json.dump(nextWordCount, f, ensure_ascii=False)