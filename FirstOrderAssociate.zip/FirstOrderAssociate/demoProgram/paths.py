#文件路径
fileIndexsPath = "../files/fileIndexs.json"#文档序号文件路径
invertedIndexPath = "../files/invertedIndex.json"#倒排索引文件路径
wordCountPath = "../files/wordCount.json"#词语次数文件路径
nextWordCountPath = "../files/nextWordCount.json"#词语相邻词语次数文件路径
fileDicPath = "../files/documents"#文档文件夹