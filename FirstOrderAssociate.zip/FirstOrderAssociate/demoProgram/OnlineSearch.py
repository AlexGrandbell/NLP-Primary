from readFiles import *
import jieba

#主函数
def main():
    print("正在读取文档序号文件")
    fileIndexs: dict[int,str] = readFileIndexs()
    print("读取文档序号文件成功！\n")

    print("正在读取倒排索引文件")
    invertedIndex: dict[str,set[int]] = readInvertedIndex()
    print("读取倒排索引文件成功！\n")

    #用户输入一句话，对其进行分词，并且查找同时包含这几个词语的文件
    while True:
        sentence = input("请输入一句搜索语句：")
        words = jieba.lcut(sentence)#对用户输入的句子进行分词
        #找到同时包含这几个词语的文件
        fileIndexes = set()
        for word in words:
            print(word)
            if word in invertedIndex:
                if len(fileIndexes) == 0:
                    fileIndexes = invertedIndex[word]
                else:
                    fileIndexes = fileIndexes & invertedIndex[word]#取交集
            else:
                fileIndexes = set()
                break
        #打印找到的文件
        if len(fileIndexes) == 0:
            print("没有找到同时包含这几个词语的文件")
        else:
            print("找到同时包含这几个词语的文件：")
            for fileIndex in fileIndexes:
                print(fileIndexs[fileIndex])
        print("\n")
        #询问用户是否继续
        isContinue = input("是否继续搜索？(y/n)")
        if isContinue == 'n':
            break

if __name__ == "__main__":
    main()