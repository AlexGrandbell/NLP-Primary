import os
from paths import *
import json

#读取原有文档序号
def readFileIndexs():
    #如果文档序号文件不存在，返回空字典
    if not os.path.exists(fileIndexsPath):
        return {}

    with open(fileIndexsPath, 'r', encoding='utf-8') as f:
        fileIndexs = json.load(f)
        #将dict[str,str]类型转换为dict[int,str]类型
        fileIndexs = {int(key): value for key, value in fileIndexs.items()}

    return fileIndexs

#读取已有的倒排索引
def readInvertedIndex():
    #如果倒排索引文件不存在，返回空字典
    if not os.path.exists(invertedIndexPath):
        return {}

    #读取到的是dict[str,list[int]]类型，需要转换为dict[str, set[int]]类型
    with open(invertedIndexPath, 'r', encoding='utf-8') as f:
        invertedIndex = json.load(f)
        invertedIndex = {key: set(value) for key, value in invertedIndex.items()}

    return invertedIndex

#读取已有的词语次数
def readWordCount():
    #如果词语次数文件不存在，返回空字典
    if not os.path.exists(wordCountPath):
        return {}

    with open(wordCountPath, 'r', encoding='utf-8') as f:
        wordCount = json.load(f)

    return wordCount

#读取已有的词语相邻词语次数
def readNextWordCount():
    #如果词语相邻词语次数文件不存在，返回空字典
    if not os.path.exists(nextWordCountPath):
        return {}

    with open(nextWordCountPath, 'r', encoding='utf-8') as f:
        nextWordCount = json.load(f)

    return nextWordCount