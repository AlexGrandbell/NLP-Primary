import jieba#导入jieba分词
from readFiles import *#导入读文件的函数
from writeFiles import *#导入写文件的函数

#将还未读取的文件添加到文档序号文件，并返回只包含新的文档序号以便添加倒排索引
def addFileIndexs(oldFileIndexs):
    newFileIndexs:dict[int,str] = {}
    #新文档序号从原有文档序号的大小开始
    i = len(oldFileIndexs)
    for root, dirs, files in os.walk(fileDicPath):
        for file in files:
            #文件名不能是.DS_Store
            if file == ".DS_Store":
                continue
            #如果文件不在原有文档序号对应的值中，就添加到新文档序号中
            if file not in oldFileIndexs.values():
                oldFileIndexs[i] = file
                newFileIndexs[i] = file
                i += 1
                print("发现新文件：" + file)
    return newFileIndexs

#将新文件的词语添加到倒排索引并且修改词语相邻词语次数
def addInvertedIndexandWordCount(invertedIndex, wordCount,nextWordCount, newFileIndexs):
    for index, file in newFileIndexs.items():
        with open(fileDicPath + "/" + file, 'r', encoding='utf-8') as f:
            content = f.read()
            words = jieba.cut(content)#使用jieba分词
            words = list(words)
            for i in range(len(words)):
                word = words[i]
                #如果词语不在词语次数中，就添加到词语次数中
                if word not in wordCount:
                    wordCount[word] = 1
                else:
                    wordCount[word] += 1
                #如果词语不在词语相邻词语次数中，就添加到词语相邻词语次数中
                if word not in nextWordCount:
                    nextWordCount[word] = {}
                if i != len(words) - 1:
                    nextWord = words[i + 1]
                    #英语排除空格，并添加空格后的词语
                    if nextWord == " ":
                        if i != len(words) - 2:
                            nextWord = words[i + 2]
                            i += 1
                    if nextWord not in nextWordCount[word]:
                        nextWordCount[word][nextWord] = 1
                    else:
                        nextWordCount[word][nextWord] += 1
                #如果词语不在倒排索引中，就添加到倒排索引中
                if word not in invertedIndex:
                    invertedIndex[word] = set()
                invertedIndex[word].add(index)

#主函数
def main():
    print("正在读取原有文档序号...")
    oldFileIndexs: dict[int,str] = readFileIndexs()
    print("读取原有文档序号成功！\n")

    print("正在获取新文件...")
    newFileIndexs: dict[int,str] = addFileIndexs(oldFileIndexs)#现在的oldFileIndexs已经包含了新的文件

    if len(newFileIndexs) == 0:
        print("没有发现新文件，程序结束。")
        return
    else:
        print("获取新文件成功！\n")

    print("正在写入新文档序号...")
    writeFileIndexs(oldFileIndexs)
    print("写入新文档序号成功！\n")

    print("正在读取已有的倒排索引...")
    invertedIndex: dict[int,set[int]] = readInvertedIndex()
    print("读取已有的倒排索引成功！\n")

    print("正在读取已有的词语次数...")
    wordCount: dict[str,int] = readWordCount()
    print("读取已有的词语次数成功！\n")

    print("正在读取已有的词语相邻词语次数...")
    nextWordCount: dict[str,dict[str,int]] = readNextWordCount()
    print("读取已有的词语相邻词语次数成功！\n")

    print("正在将新文件的词语添加到倒排索引，并且添加词频...")
    addInvertedIndexandWordCount(invertedIndex,wordCount,nextWordCount, newFileIndexs)
    print("将新文件的词语添加到倒排索引，并且添加词频成功！\n")

    print("正在写入新的倒排索引...")
    writeInvertedIndex(invertedIndex)
    print("写入新的倒排索引成功！\n")

    print("正在写入新的词语次数...")
    writeWordCount(wordCount)
    print("写入新的词语次数成功！\n")

    print("正在写入新的词语相邻词语次数...")
    writeNextWordCount(nextWordCount)
    print("写入新的词语相邻词语次数成功！\n")

if __name__ == "__main__":
    main()