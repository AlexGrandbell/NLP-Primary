from readFiles import *
import jieba

#主函数
def main():
    while True:
        sentence = input("请输入一句话：")
        words = jieba.lcut(sentence)
        #判断所有词语是否在倒排索引中
        invertedIndex = readInvertedIndex()
        for word in words:
            if word not in invertedIndex.keys():
                print("抱歉，没有找到该词语：",word,"。你的语句在此环境下是无效的。")
                return
        #找到最大概率的下一个词语
        wordCount = readWordCount()#读取词语次数
        nextWordCount = readNextWordCount()#读取词语相邻词语次数
        #最后一个词语
        lastWord = words[-1]
        isContinue = "y"
        while isContinue != "n":
            #计算最大概率的下一个词语
            lastWordCount = wordCount[lastWord]
            nextWord = ""
            maxProbability = 0
            for key in nextWordCount[lastWord].keys():
                probability = nextWordCount[lastWord][key] / lastWordCount
                if probability > maxProbability:
                    maxProbability = probability
                    nextWord = key
            print("最大概率的下一个词语是:",nextWord)
            print("连起来是：",sentence +" "+ nextWord)
            sentence += (" " + nextWord)
            lastWord = nextWord
            #询问用户是否继续
            isContinue = input("是否继续联想？(y/n)")
        #询问用户是否继续
        isContinue = input("是否重新输入？(y/n)")
        if isContinue == 'n':
            break

if __name__ == "__main__":
    main()